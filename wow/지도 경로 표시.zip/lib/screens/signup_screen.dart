import 'package:flutter/material.dart';
import 'privacy_policy_screen.dart';

class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  String? _selectedGender;
  bool _isAgreementChecked = false; // 체크박스 상태 관리

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('회원가입')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTextField('아이디'),
            _buildActionButton('중복 확인', () {}),

            SizedBox(height: 16), // 간격 추가
            _buildTextField('비밀번호', obscureText: true),
            _buildTextField('비밀번호 재입력', obscureText: true),
            _buildActionButton('비밀번호 확인', () {}),

            SizedBox(height: 16),
            _buildGenderSelection(),

            SizedBox(height: 16),
            _buildAgreementSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, {bool obscureText = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        obscureText: obscureText,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(),
        ),
      ),
    );
  }

  Widget _buildActionButton(String text, VoidCallback onPressed) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: ElevatedButton(
        onPressed: onPressed,
        child: Text(text),
      ),
    );
  }

  Widget _buildGenderSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('성별:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        Wrap(
          spacing: 16,
          children: ['남성', '여성', '비공개'].map((gender) => _buildGenderRadio(gender)).toList(),
        ),
      ],
    );
  }

  Widget _buildGenderRadio(String gender) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Radio(
          value: gender,
          groupValue: _selectedGender,
          onChanged: (value) {
            setState(() {
              _selectedGender = value.toString();
            });
          },
        ),
        Text(gender),
      ],
    );
  }

  Widget _buildAgreementSection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text('개인정보 제공에 동의합니다.'),
        Row(
          children: [
            Checkbox(
              value: _isAgreementChecked,
              onChanged: (bool? value) {
                setState(() {
                  _isAgreementChecked = value!;
                });
              },
            ),
            _buildActionButton('확인', () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => PrivacyPolicyScreen()),
              );
              if (result == true) {
                setState(() {
                  _isAgreementChecked = true;
                });
              }
            }),
          ],
        ),
      ],
    );
  }
}
