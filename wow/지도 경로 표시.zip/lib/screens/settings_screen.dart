import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String selectedOption = '';
  TextEditingController nicknameController = TextEditingController();
  String currentNickname = '사용자아이디'; // 서버에서 받아올 예정
  String gender = '비공개'; // 서버에서 받아올 성별

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('설정')),
      body: Row(
        children: [
          // 사이드 메뉴 (설정 버튼 목록)
          Container(
            width: 150,
            padding: EdgeInsets.symmetric(vertical: 16),
            color: Colors.grey[200], // 배경색 추가
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildMenuButton('개인정보 설정'),
                _buildMenuButton('개인 경로 설정'),
              ],
            ),
          ),

          // 설정 내용
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: selectedOption == '개인정보 설정'
                  ? _buildPrivacySettings()
                  : selectedOption == '개인 경로 설정'
                  ? _buildRouteSettings()
                  : Center(child: Text('설정을 선택하세요.', style: TextStyle(fontSize: 16))),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuButton(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
      child: TextButton(
        onPressed: () => setState(() => selectedOption = title),
        style: TextButton.styleFrom(
          backgroundColor: selectedOption == title ? Colors.blue[100] : Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(title, style: TextStyle(fontSize: 16, color: Colors.black)),
        ),
      ),
    );
  }

  Widget _buildPrivacySettings() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('닉네임 설정'),
        Text('현재 닉네임: $currentNickname', style: TextStyle(fontSize: 16)),
        SizedBox(height: 8),
        TextField(
          controller: nicknameController,
          decoration: InputDecoration(
            labelText: '변경할 닉네임 입력',
            border: OutlineInputBorder(),
          ),
        ),
        SizedBox(height: 8),
        _buildButtonRow(['중복 확인', '닉네임 변경 확인']),

        SizedBox(height: 16),
        _buildSectionTitle('성별 변경'),
        _buildGenderSelection(),
        SizedBox(height: 8),
        ElevatedButton(
          onPressed: () {},
          child: Text('확인'),
        ),
      ],
    );
  }

  Widget _buildRouteSettings() {
    return Center(
      child: Text('개인 경로 설정', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildGenderSelection() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        _genderButton('남자', '0'),
        _genderButton('여자', '1'),
        _genderButton('비공개', '2'),
      ],
    );
  }

  Widget _genderButton(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4.0),
      child: ElevatedButton(
        onPressed: () => setState(() => gender = value),
        style: ElevatedButton.styleFrom(
          backgroundColor: gender == value ? Colors.blue : Colors.grey,
        ),
        child: Text(label, style: TextStyle(color: Colors.white)),
      ),
    );
  }

  Widget _buildButtonRow(List<String> buttonLabels) {
    return Row(
      children: buttonLabels.map((label) => Padding(
        padding: const EdgeInsets.only(right: 8.0),
        child: ElevatedButton(
          onPressed: () {},
          child: Text(label),
        ),
      )).toList(),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }
}
