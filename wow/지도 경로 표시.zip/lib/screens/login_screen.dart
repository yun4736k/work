import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'signup_screen.dart';
import 'home_screen.dart';
import 'package:geolocator/geolocator.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _requestLocationPermission();
  }

  Future<void> _requestLocationPermission() async {
    LocationPermission permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) {
      _showSnackBar('위치 권한이 거부되었습니다.');
    } else if (permission == LocationPermission.deniedForever) {
      _showSnackBar('위치 권한이 영구적으로 거부되었습니다. 설정에서 변경하세요.');
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> login(String username, String password) async {
    final url = Uri.parse('http://192.168.18.158:5000/login');

    try {
      final response = await http.post(
        url,
        body: json.encode({'id': username, 'pw': password}),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        if (responseData['status'] == 'success') {
          _showSnackBar(responseData['message']);
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => HomeScreen()),
          );
        } else {
          _showSnackBar(responseData['message']);
        }
      } else {
        _showSnackBar('서버 오류: ${response.statusCode}');
      }
    } catch (error) {
      _showSnackBar('네트워크 오류: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Walk Canvas')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildTextField(_usernameController, '아이디'),
            SizedBox(height: 12),
            _buildTextField(_passwordController, '비밀번호', obscureText: true),
            SizedBox(height: 24),
            _buildMainButton('로그인', () {
              login(_usernameController.text, _passwordController.text);
            }),
            SizedBox(height: 12),
            TextButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SignUpScreen()),
              ),
              child: Text('회원 가입', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.of(context).pop(),
        child: Icon(Icons.exit_to_app),
        tooltip: '종료',
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String labelText, {bool obscureText = false}) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      decoration: InputDecoration(
        labelText: labelText,
        border: OutlineInputBorder(),
      ),
    );
  }

  Widget _buildMainButton(String text, VoidCallback onPressed) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: onPressed,
        child: Text(text, style: TextStyle(fontSize: 18)),
      ),
    );
  }
}
